## 约束最小二乘方

用到了 matlab 里 `psf2otf` 的函数  

https://blog.csdn.net/cjsh_123456/article/details/79369611  
https://blog.csdn.net/wsp_1138886114/article/details/95024180 （含部分代码）
https://blog.csdn.net/yi_tech_blog/article/details/54605146 (含推导)  

## L-R 滤波

似乎是极大似然算法，又似乎是 Rechardson-Lucy 算法，总之资料很少

https://wenku.baidu.com/view/394905114431b90d6c85c751.html  
https://scikit-image.org/docs/dev/auto_examples/filters/plot_deconvolution.html  
https://en.wikipedia.org/wiki/Richardson%E2%80%93Lucy_deconvolution

## 正则滤波

找不到……
